//
//  ViewController.swift
//  timeTouch
//
//  Created by Ione Axelrod on 4/19/17.
//  Copyright © 2017 Ione Axelrod. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var surpriseTimer = Timer()
    var timeToPressTimer = Timer()
    var elapsed: Double = 0
    
    @IBOutlet weak var theLabel: UILabel!

    func randomTime() -> TimeInterval {
        return TimeInterval(arc4random_uniform(20) + 5)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        surpriseTimer = Timer.scheduledTimer(timeInterval: randomTime(), target: self, selector: #selector(surprise), userInfo: nil, repeats: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func pressButton(_ sender: UIButton) {
        
        if theLabel.text != "HIT THE BUTTON" {
            
            theLabel.textColor = UIColor.darkGray
            theLabel.text = "I DIDNT TELL YOU TO HIT THE BUTTON"
        } else {
            theLabel.textColor = UIColor.darkGray

            theLabel.text = "Time It Took to Press: \(elapsed) secs"
        }
        
        
        timeToPressTimer.invalidate()
        elapsed = 0
        
    }
    
    func surprise() {
        
        theLabel.textColor = UIColor.red
        theLabel.text = "HIT THE BUTTON"
        timeToPressTimer.fire()
        timeToPressTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(update), userInfo: nil, repeats: true)

    }
    
    func update() {
        elapsed += 0.1
    }
    
}

