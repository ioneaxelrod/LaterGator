//
//  model.swift
//  timeTouch
//
//  Created by Ione Axelrod on 4/19/17.
//  Copyright © 2017 Ione Axelrod. All rights reserved.
//

import Foundation
